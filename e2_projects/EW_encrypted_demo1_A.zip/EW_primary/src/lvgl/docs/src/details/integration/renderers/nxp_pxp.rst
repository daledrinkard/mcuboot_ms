===========
NXP PXP GPU
===========

API
***

:ref:`lv_draw_pxp_h`

:ref:`lv_pxp_cfg_h`
