==================
Renderers and GPUs
==================

.. toctree::
    :maxdepth: 2

    sw
    arm2d
    nema_gfx
    nxp_pxp
    nxp_vglite_gpu
    nxp_g2d
    sdl
    stm32_dma2d
    vg_lite
