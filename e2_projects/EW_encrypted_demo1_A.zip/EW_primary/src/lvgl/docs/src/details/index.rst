.. _reference:

=======
Details
=======

.. toctree::
    :maxdepth: 2

    ../examples
    integration/index
    common-widget-features/index
    widgets/index
    main-modules/index
    auxiliary-modules/index
    libs/index
    debugging/index
    ../contributing/index
    ../CHANGELOG
    ../API/index
