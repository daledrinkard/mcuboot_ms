.. _xml_view:

=========
View
=========

TODO