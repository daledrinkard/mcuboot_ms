/*
 * memdump.h
 *
 *  Created on: Apr 26, 2025
 *      Author: daled
 */

#ifndef MEMDUMP_MEMDUMP_H_
#define MEMDUMP_MEMDUMP_H_

#include "memdump_cfg.h"

char* memdump(uint8_t *data, uint32_t len);

#endif /* MEMDUMP_MEMDUMP_H_ */
