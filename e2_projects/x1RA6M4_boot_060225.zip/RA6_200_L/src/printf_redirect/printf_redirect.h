/*
 * printf_redirect.h
 *
 *  Created on: May 21, 2024
 *      Author: daled
 */

#ifndef PRINTF_REDIRECT_H_
#define PRINTF_REDIRECT_H_

#include "printf_redirect_cfg.h"

#endif /* PRINTF_REDIRECT_H_ */
