/*
 * memdump_cfg.h
 *
 *  Created on: Apr 26, 2025
 *      Author: daled
 */

#ifndef MEMDUMP_MEMDUMP_CFG_H_
#define MEMDUMP_MEMDUMP_CFG_H_

#define HDR_PRIMARY (0x00020000)
#define TRL_PRIMARY (0x0005FFF0)

#define HDR_SCRATCH (0x00060000)
#define TRL_SCRATCH (0x0009FFF0)

#define MD_BUFFER_SIZE 128

#endif /* MEMDUMP_MEMDUMP_CFG_H_ */
