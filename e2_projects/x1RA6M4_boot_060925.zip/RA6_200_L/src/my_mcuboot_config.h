
#ifndef MY_MCUBOOT_CONFIG_H_
#define MY_MCUBOOT_CONFIG_H_

//#define MCUBOOT_HAS_RESOURCES (1)
//@@ #define XSPI_AREA_MCUBOOT_OFFSET 0x01000000  //<-- puts MCUboot partition at 16MB (half way)
//@@   actually discovered that the QSPI is 16M and 0x61000000 is an alias of 0x60000000.  Don't know if that's a setup issue or not.
#define XSPI_AREA_MCUBOOT_OFFSET 0x00800000  //<-- puts MCUboot partition at 8MB because of issues with jlink

#define RESOURCES_SIZE  (1024*1024)
#define RESOURCE_IMAGE_SECTORS (RESOURCE_SIZE / BSP_FEATURE_FLASH_HP_CF_REGION1_BLOCK_SIZE)

#if 1
/** Area that is linked in the application **/
#define FLASH_AREA_RESOURCES_OFFSET (BSP_FEATURE_QSPI_DEVICE_START_ADDRESS)
#define FLASH_AREA_RESOURCES_SIZE (RESOURCES_SIZE)

/** Area that holds the update OTA **/
#define FLASH_AREA_RESOURCES_UPDATE_OFFSET (BSP_FEATURE_QSPI_DEVICE_START_ADDRESS + XSPI_AREA_MCUBOOT_OFFSET)
#define FLASH_AREA_RESOURCESUPDATE_SIZE (RESOURCES_SIZE)
#endif

#define MCUBOOT_MAX_IMG_SECTORS 32

#endif /* MY_MCUBOOT_CONFIG_H_ */
