=================
Software Renderer
=================

API
***

.. API startswith:  lv_draw_sw
