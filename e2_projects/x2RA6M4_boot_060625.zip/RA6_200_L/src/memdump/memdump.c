/*
 * memdump.c
 *
 *  Created on: Apr 26, 2025
 *      Author: daled
 */

#include <stdint.h>
#include "memdump.h"
#include "stdio.h"

static char md_buffer[MD_BUFFER_SIZE];

char* memdump(uint8_t *data, uint32_t len)
{
    uint8_t *p;
    char *q;
    uint32_t i;
    uint8_t tmp;
    i = len;
    p = data;
    q = &md_buffer[0];
    while(i)
    {
        *q = '0';q++;*q='x';q++;
        tmp = ((*p & 0xF0)>>4);
        *q = (char) ((tmp > 9) ? (tmp+('A'-10)) : (tmp+'0'));
        q++;
        tmp = (*p & 0x0F);
        *q = (char) ((tmp > 9) ? (tmp+('A'-10)) : (tmp+'0'));
        q++;
        *q = ' ';
        q++;
        p++;
        i--;
    }
    *q = 0;
    return &md_buffer[0];
}
