/***********************************************************************************************************************
 * File Name    : downloader_thread_entry.c
 * Description  : Contains Downloader Thread Implementation
 ***********************************************************************************************************************/

/***********************************************************************************************************************
* Copyright (c) 2020 - 2024 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
***********************************************************************************************************************/
#include "downloader_thread.h"
#include "header.h"
#include "comms.h"
#include "stdio.h"
#include "menu.h"
#include "qspi_operations.h"
#include "resources/resource.h"
#include "memdump/memdump.h"
void set_flash_index(int idx);
//@@void dump_stuff(void);
volatile uint32_t user_flags;
//@@ added this
struct image_header * p_ap_header;
struct image_header * p_rs_header;
const char bettywhite[512*1024] = {"512k"};
void display_image_slot_info(void)
{
    uint8_t str[100];

    struct image_version {
        uint8_t iv_major;
        uint8_t iv_minor;
        uint16_t iv_revision;
        uint32_t iv_build_num;
    };

    struct image_header {
        uint32_t ih_magic;
        uint32_t ih_load_addr;
        uint16_t ih_hdr_size;            /* Size of image header (bytes). */
        uint16_t ih_protect_tlv_size;    /* Size of protected TLV area (bytes). */
        uint32_t ih_img_size;            /* Does not include header. */
        uint32_t ih_flags;               /* IMAGE_F_[...]. */
        struct image_version ih_ver;
        uint32_t _pad1;
    };


    struct image_header * p_img_header;
    /* Primary Image Slot */
    p_img_header = (struct image_header *)PRIMARY_IMAGE_START_ADDRESS;
    snprintf((char *)str, sizeof(str), "*************************\r\n");
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "* Primary Image Slot *\r\n");
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "*************************\r\n");
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "Image version: \t\t%02d.%02d (Rev: %d, Build: %ld)\r\n", p_img_header->ih_ver.iv_major,
                                                                                             p_img_header->ih_ver.iv_minor,
                                                                                             p_img_header->ih_ver.iv_revision,
                                                                                             p_img_header->ih_ver.iv_build_num);
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "Primary image start address: \t\t0x%08X\r\n", (unsigned int)PRIMARY_IMAGE_START_ADDRESS);
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "Header size: \t\t0x%04X (%d bytes)\r\n", p_img_header->ih_hdr_size, p_img_header->ih_hdr_size);
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "Protected TLV size: \t0x%04X (%d bytes)\r\n", p_img_header->ih_protect_tlv_size, p_img_header->ih_protect_tlv_size);
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "Image size: \t\t0x%08X (%ld bytes)\r\n", (unsigned int)p_img_header->ih_img_size, p_img_header->ih_img_size);
    comms_send(str, strlen((char *)str));

    /* Secondary S Image Slot */
    p_img_header = (struct image_header *)SECONDARY_IMAGE_START_ADDRESS;
    snprintf((char *)str, sizeof(str), "\r\n**************************\r\n");
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "* Secondary Image Slot *\r\n");
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "**************************\r\n");
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "Image version: \t\t%02d.%02d (Rev: %d, Build: %ld)\r\n", p_img_header->ih_ver.iv_major,
                                                                                             p_img_header->ih_ver.iv_minor,
                                                                                             p_img_header->ih_ver.iv_revision,
                                                                                             p_img_header->ih_ver.iv_build_num);
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "Secondary image start address: \t\t0x%08X\r\n", (unsigned int)SECONDARY_IMAGE_START_ADDRESS);
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "Header size: \t\t0x%04X (%d bytes)\r\n", p_img_header->ih_hdr_size, p_img_header->ih_hdr_size);
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "Protected TLV size: \t0x%04X (%d bytes)\r\n", p_img_header->ih_protect_tlv_size, p_img_header->ih_protect_tlv_size);
    comms_send(str, strlen((char *)str));
    snprintf((char *)str, sizeof(str), "Image size: \t\t0x%08X (%ld bytes)\r\n", (unsigned int)p_img_header->ih_img_size, p_img_header->ih_img_size);
    comms_send(str, strlen((char *)str));


}

usb_callback_t g_usb_cb;

static void confirm_image(void);
static int check_confirmed(void);
static int check_confirmed(void)
{
    int rc;
    uint8_t ok_flag[2];
    const struct flash_area *fapL;
    set_flash_index(0);
    rc = flash_area_open(FLASH_AREA_IMAGE_PRIMARY(0), &fapL);
    boot_read_image_ok(fapL, &ok_flag[0]);
    set_flash_index(1);
    rc = flash_area_open(FLASH_AREA_IMAGE_PRIMARY(0), &fapL);
    assert(0 == rc);
    boot_read_image_ok(fapL, &ok_flag[1]);
    rc = (ok_flag[0] == BOOT_FLAG_SET) ? (ok_flag[1] == BOOT_FLAG_SET) ? 0 : 2 :
                                         (ok_flag[1] == BOOT_FLAG_SET) ? 1 : 3;
    return rc;
}
volatile char* tbo;

static void confirm_image(void)
{
    //struct flash_area *fapL;

    int rc;
    volatile struct image_header * pa,*pr;
    fsp_err_t err;
    err = R_ICU_ExternalIrqOpen(&g_SW2_ctrl, &g_SW2_cfg);
    err |= R_ICU_ExternalIrqEnable(&g_SW2_ctrl);
    assert(FSP_SUCCESS == err);
    user_flags = 0;

    pa = (struct image_header *)PRIMARY_IMAGE_START_ADDRESS;
    pr = (struct image_header *)RESOURCE_IMAGE_START_ADDRESS;
    do {
        //dump_stuff();
        rc = check_confirmed();
        switch (rc) {
            case 0: printf("\nNo updates detected\n"); break;
            case 1: printf("\nAPP updated\n"); break;
            case 2: printf("\nRES updated\n"); break;
            case 3: printf("\n APP and RES updated\n"); break;
        }
        if ((rc & 3) > 0) // something has updated, so validate the version compatibility
        {
            if ((pa->ih_ver.iv_major == pr->ih_ver.iv_major) &&
                (pa->ih_ver.iv_minor == pr->ih_ver.iv_minor))
            {
                printf("version numbers match\n");
            }
            else
            {
                printf("The version numbers do not compare.\n");
                        //@@ NVIC_SystemReset();
            }

        }
        if (rc & 3) // either image
        {
            printf("\nPress SW2 to confirm this image\n");
            user_flags = 0;
            while((user_flags & 2) == 0);
        }
        if (rc & 1)
        {
            printf("confirm APP\n");
            set_flash_index(0);
            boot_set_confirmed_multi(0);
        }
        if (rc & 2)
        {
            printf("confirm RES\n");
            set_flash_index(1);
            boot_set_confirmed_multi(0);
        }
        rc = 0;
    } while(rc);
}
#if 0
void dump_stuff(void)
{
    uint32_t addr;

    addr = 0x00020000;
    tbo = memdump((uint8_t*) addr, 16);
    printf("\nprimary  HDR 0x%08lX %s\n",addr,tbo);

    addr = 0x0005FFF0;
    tbo = memdump((uint8_t*) addr, 16);
    printf("primary  TLR 0x%08lX %s\n",addr,tbo);

    addr = 0x60000000;
    tbo = memdump((uint8_t*) addr, 16);
    printf("resource HDR 0x%08lX %s\n",addr,tbo);

    addr = 0x600FFFF0;
    tbo = memdump((uint8_t*) addr, 16);
    printf("resource TLR 0x%08lX %s\n",addr,tbo);

    addr = 0x0005FF00;
    tbo = memdump((uint8_t*) addr, 16);
    printf("mem 0x%08lX %s\n",addr,tbo);

    addr = 0x600FFF00;
    tbo = memdump((uint8_t*) addr, 16);
    printf("mem 0x%08lX %s\n",addr,tbo);

}
#endif
/* Downloader Thread entry function */
/* pvParameters contains TaskHandle_t */
void downloader_thread_entry(void *pvParameters)
{
    FSP_PARAMETER_NOT_USED (pvParameters);
    fsp_err_t err;
    volatile struct image_header * pa,*pr;
    init_qspi();
    pa = (struct image_header *)PRIMARY_IMAGE_START_ADDRESS;
    pr = (struct image_header *)RESOURCE_IMAGE_START_ADDRESS;
    printf("-------------------------------------------------------------\n");
    printf("\r\nStarting Application %d.%d.%d Resource %d.%d.%d\n",
            pa->ih_ver.iv_major,pa->ih_ver.iv_minor,pa->ih_ver.iv_revision,
            pr->ih_ver.iv_major,pr->ih_ver.iv_minor,pr->ih_ver.iv_revision);
    confirm_image();
    printf("Resource: %s\n",resources.data);
    printf("Flash: %s\n",bettywhite);
#ifdef _BCFG
    switch (_BCFG) {
        case 0: printf("DEBUG\n");break;
        case 1: printf("Bootable\n");break;
        case 2: printf("Signed\n");break;
        case 3: printf("Encypted\n");break;
    }
#else
    printf("unknown\n");
#endif
    printf("-------------------------------------------------------------\n");


    /* Open the comms driver */
    err = comms_open();
    if (FSP_SUCCESS != err)
    {
        /* Stop as comms open failure */
        while(1)
        {
            ;
        }
    }
    //   err =   R_FLASH_HP_Open(&g_flash0_ctrl, &g_flash0_cfg);
    while(1)
    {
        menu();
        vTaskDelay (1);
    }

}

/* Callback function */
void SW2_cb(external_irq_callback_args_t *p_args)
{
    /* TODO: add your own code here */
    FSP_PARAMETER_NOT_USED(p_args);
    user_flags |= 2;
}
