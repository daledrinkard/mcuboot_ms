/*
 * printf_redirect_cfg.h
 *
 *  Created on: May 21, 2024
 *      Author: daled
 */

#ifndef PRINTF_REDIRECT_CFG_H_
#define PRINTF_REDIRECT_CFG_H_

#define PRINTF_RX_BUFFER_LENGTH (128)
#define PRINTF_USE_SCI_B  (0)

#endif /* PRINTF_REDIRECT_CFG_H_ */
